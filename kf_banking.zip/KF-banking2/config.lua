-- LEALTAD-BANKING CONFIG

Config = {}

Config.Zonas = {
    ["banks"] = {
      },
    ["atms"] = {
    }   
}