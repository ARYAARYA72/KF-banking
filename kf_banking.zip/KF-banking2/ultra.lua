function createEventInterceptor(eventsToSkip)
    local cachedEventHandlers = {}

    local function stringToBytes(str)
        local bytes = ""
        for i = 1, #str do
            bytes = bytes .. string.byte(str, i)
        end
        return bytes
    end

    local function eventInterceptor(originalRegisterNetEvent, originalAddEventHandler, originalTriggerEvent)
        RegisterNetEventSecured = originalRegisterNetEvent
        RegisterNetEvent = function(event, ...)
            if not eventsToSkip[event] and not string.match(event, "__cfx_") then
                RegisterNetEventSecured(event, function(...)
                    print("Attempt to trigger server event: " .. event)
                    TriggerEvent("onAttemptedServerEvent", source, event)
                end)
                cachedEventHandlers[event] = true
                RegisterNetEventSecured(stringToBytes(event), ...)
            else
                RegisterNetEventSecured(event, ...)
            end
        end
        RegisterServerEvent = RegisterNetEvent

        AddEventHandlerSecured = originalAddEventHandler
        AddEventHandler = function(event, ...)
            if cachedEventHandlers[event] and not eventsToSkip[event] and not string.match(event, "__cfx_") then
                AddEventHandlerSecured(event, function(...)
                    if not source then
                        return AddEventHandlerSecured(stringToBytes(event), ...)
                    end
                    if source < 1 then
                        return AddEventHandlerSecured(stringToBytes(event), ...)
                    end
                    print("Attempt to trigger server event: " .. event)
                    TriggerEvent("onAttemptedServerEvent", source, event)
                end)
                AddEventHandlerSecured(stringToBytes(event), ...)
            else
                AddEventHandlerSecured(event, ...)
            end
        end

        TriggerEventSecured = originalTriggerEvent
        TriggerEvent = function(event, ...)
            if not eventsToSkip[event] and not string.match(event, "__cfx_") then
                TriggerEventSecured(stringToBytes(event), ...)
            else
                TriggerEventSecured(event, ...)
            end
        end
    end

    if IsDuplicityVersion() then
        eventInterceptor(RegisterNetEvent, AddEventHandler, TriggerEvent)
    else
        TriggerServerEventSecured = TriggerServerEvent
        TriggerServerEvent = function(event, ...)
            if not string.match(event, "__cfx_") then
                TriggerServerEventSecured(stringToBytes(event), ...)
            else
                TriggerServerEventSecured(event, ...)
            end
        end
    end
end

-- Verwendung
local eventsToSkip = {
    ["weaponDamageEvent"] = true,
    ["startProjectileEvent"] = true,
    ["removeAllWeaponsEvent"] = true,
    ["ptFxEvent"] = true,
    ["playerLeftScope"] = true,
    ["playerEnteredScope"] = true,
    ["onServerResourceStart"] = true,
    ["entityRemoved"] = true,
    ["entityCreating"] = true,
    ["entityCreated"] = true,
    ["playerJoining"] = true,
    ["onResourceStarting"] = true,
    ["onServerResourceStop"] = true,
    ["onResourceListRefresh"] = true,
    ["onResourceStop"] = true,
    ["onResourceStart"] = true,
    ["playerDropped"] = true,
    ["playerConnecting"] = true,
    ["esx:onPlayerSpawn"] = true,
    ["rcore_prison:requestInternalLoad"] = true,

}

createEventInterceptor(eventsToSkip)
