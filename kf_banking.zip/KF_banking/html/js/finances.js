const load = (atm, transferTax, taxBracket, taxPercentage, totalValue, debtAmount, salaryNumber, salaryAfterTaxes, canTakeSalary) => {
    if (atm) {
        $("#section_salary")['hide']();
        $("#section_wire-transfer")['hide']();
        $('#section_deposit-withdraw')["show"]();
        $("#section_taxes-debt")["hide"]();
        switchToPanel($("#deposit-withdraw"));
    } else {
        if(canTakeSalary) $("#section_salary")["show"](); else $("#section_salary")["hide"]();
        $("#section_wire-transfer")["show"]();
        $("#section_deposit-withdraw")["show"]();
        $("#section_taxes-debt")["hide"]();
        if(canTakeSalary) switchToPanel($('#salary')); else switchToPanel($('#deposit-withdraw'));
    }
    $(".transferTax")["text"](transferTax);
    $(".taxBracket")['text'](taxBracket);
    $(".taxPercentage")["text"](taxPercentage);
    $(".totalValue")['text'](totalValue);
    $('#debtAmount')["val"](debtAmount);
    $("#salaryNumber")["text"](salaryNumber);
    $("#salaryAfterTaxes")['text'](salaryAfterTaxes);
};

function refresh(transferTax, taxBracket, taxPercentage, totalValue, debtAmount, salaryNumber, salaryAfterTaxes){
    $(".transferTax")["text"](transferTax);
    $(".taxBracket")['text'](taxBracket);
    $(".taxPercentage")["text"](taxPercentage);
    $(".totalValue")['text'](totalValue);
    $('#debtAmount')["val"](debtAmount);
    $("#salaryNumber")["text"](salaryNumber);
    $("#salaryAfterTaxes")['text'](salaryAfterTaxes);
};

$("#takeSalary")['on']("click", function () {
    $.post(`https://${GetParentResourceName()}/takeSalary`, JSON.stringify({}));
});

$("#transfer")['on']("click", function () {
    let transferAmount = $("#transferAmount")["val"]();
    let id = $("#transferName")['val']();
    $.post(`https://${GetParentResourceName()}/transfer`, JSON.stringify({id: id, amount: transferAmount}));
});

$("#debt")['on']('click', function () {
    let debtAmount = $("#debtAmount")["val"]();
    // eclipseTrigger('PAY_DEBT', debtAmount);
});

$("#withdraw")['on']("click", function () {
    let withdrawAmount = $('#withdrawAmount')["val"]();
    $.post(`https://${GetParentResourceName()}/withdraw`, JSON.stringify({amount: withdrawAmount}));
});

$("#deposit")['on']("click", function () {
    let depositAmount = $('#depositAmount')['val']();
    $.post(`https://${GetParentResourceName()}/deposit`, JSON.stringify({amount: depositAmount}));
});

window.addEventListener('message', function(event) {
	if (event.data.type === "open"){
	    load(event.data.data.atm, event.data.data.transferTax, 0, event.data.data.taxPercentage, 0, 0, event.data.data.salaryNumber, event.data.data.salaryAfterTaxes, event.data.data.canTakeSalary)
        $('body').show();
	} else if(event.data.type === "refresh") {
        refresh(event.data.data.transferTax, 0, event.data.data.taxPercentage, 0, 0, event.data.data.salaryNumber, event.data.data.salaryAfterTaxes)
	} else if (event.data.type === "close"){
        $('body').hide();
	}
});

$("body").on("keyup", function (key) {
    if ([113, 27, 90].includes(key.which)) {
        $.post(`https://${GetParentResourceName()}/NUIFocusOff`, JSON.stringify({}));
    }
});