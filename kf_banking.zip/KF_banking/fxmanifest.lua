

-- Resource Metadata
fx_version 'cerulean'
games { 'gta5' }

ui_page 'html/finance.html'

server_scripts {
    'server/*.lua',
    'config.lua'
}

client_scripts {
    'client/*.lua',
    'config.lua'
}

files {
	'html/*.html',
    'html/css/*.css',
    'html/images/*.png',
    'html/js/*.js',
    'html/webfonts/*.ttf',
    'html/webfonts/*.woff2',
    'html/webfonts/*.otf'
}