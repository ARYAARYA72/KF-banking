
local PlayerData = {}
local dataStore = {}
local newarBankOrATM = false
Citizen.CreateThread(function()
	ESX = exports["es_extended"]:getSharedObject()
	
	while PlayerData.job == nil do
		PlayerData = ESX.GetPlayerData()
		Citizen.Wait(0)
	end
end)

AddEventHandler('onResourceStop', function(resourceName)
	if (GetCurrentResourceName() ~= resourceName) then
		return
	end
	for k, bank in pairs(Config.Banks) do
		if bank.ped then
			if bank.ped.entity then
				DeleteEntity(bank.ped.entity)
			end
		end
	end
end)

Citizen.CreateThread(function()
	wait = 500
    while true do
    	local newarBankOrATM = false
        for _, bank in pairs(Config.Banks) do
	        local player = PlayerPedId()
	        local dist = GetDistanceBetweenCoords(GetEntityCoords(player), bank.coords.x, bank.coords.y, bank.coords.z, true)
			if dist < 5 then
				newarBankOrATM = true
				if bank.ped then
					if bank.ped.entity then
						if bank.ped.animation then
							while not HasAnimDictLoaded(bank.ped.animation.dict) do
								RequestAnimDict(bank.ped.animation.dict)
							    Citizen.Wait(0)
							end
							if not IsEntityPlayingAnim(bank.ped.entity, bank.ped.animation.dict, bank.ped.animation.name, 3) then
								SetEntityHeading(bank.ped.entity, bank.ped.coords.h)
								TaskPlayAnim(bank.ped.entity, bank.ped.animation.dict, bank.ped.animation.name, 2.0, 2.0, -1, 1, 0, false, false, false)
							end
						end
					end
				end
				Draw3DText(bank.coords.x, bank.coords.y, bank.coords.z, "Press ~g~[E]~b~ To Open ~p~Bank~b~!", { red = 255, green = 199, blue = 43, alpha = 180 }, 4, 0.1)
    			if dist < 1 then
					if IsControlJustReleased(0, 38) then
						if IsPedInAnyVehicle(PlayerPedId()) then
							ESX.ShowNotification('Please Exit Your Vehicle!')
						else
							openBank(false, bank.takeSalary)
						end
					end
    			end
			end
        end
        for _, atm in pairs(Config.Atms) do
	        local player = PlayerPedId()
	        local dist = GetDistanceBetweenCoords(GetEntityCoords(player), atm.coords.x, atm.coords.y, atm.coords.z, true)
			if dist < 5 then
				newarBankOrATM = true
				Draw3DText(atm.coords.x, atm.coords.y, atm.coords.z, "Press ~g~[E]~b~ To Open ~p~ATM~b~!", { red = 255, green = 199, blue = 43, alpha = 180 }, 4, 0.1)
    			if dist < 1 then
					if IsControlJustReleased(0, 38) then
						ClearPedTasks(PlayerPedId())
						TaskStartScenarioInPlace(PlayerPedId(), "PROP_HUMAN_ATM", 0, true)
						Citizen.Wait(2000)
                        openBank(true)
					end
    			end
			end
        end
        if newarBankOrATM then
			wait = 5
		else
			wait = 500
		end
        Citizen.Wait(wait)
    end
end)



function Draw3DText(x, y, z, text, color, font, scaleplus) 
	local onScreen, _x, _y = GetScreenCoordFromWorldCoord(x, y, z) 
    local scale = 0.30
	if not scaleplus then
		scaleplus = 0
	end
	if onScreen then
		SetTextFont(font)
		SetTextScale(scale+scaleplus, scale+scaleplus)
		SetTextProportional(true)
		-- SetTextColour(210, 210, 210, 180)
		SetTextColour(color.red, color.green, color.blue, color.alpha)
		SetTextCentre(true)
		SetTextDropshadow(50, 210, 210, 210, 255)
		SetTextOutline()
		SetTextEntry("STRING")
		AddTextComponentString(text)
		DrawText(_x, _y - 0.035)
	end
end

function getAccount(account)
	PlayerData = ESX.GetPlayerData()
	while PlayerData.accounts == nil do
		PlayerData = ESX.GetPlayerData()
		Citizen.Wait(0)
	end
	for k,v in ipairs(PlayerData.accounts) do
		if v.name == account then
			return v
		end
	end
end

function _CreatePed(hash, coords, heading)
    RequestModel(hash)
    while not HasModelLoaded(hash) do
        Wait(5)
    end
    local ped = CreatePed(4, hash, coords, false, false)
    SetEntityHeading(ped, heading)
	FreezeEntityPosition(ped, true)
	SetEntityInvincible(ped, true)
	SetEntityCollision(ped, false, true)
	-- SetBlockingOfNonTemporaryEvents(ped, true)
    return ped
end

function openBank(isAtm, takeSalary)
	local salary = getAccount('salary')
	local tax = 0
	local transferTax = 0
	if Config.Tax.enabled then 
		tax = Config.Tax.rate
		transferTax = Config.Tax.transfer
	end
	
	dataStore.transferTax = transferTax
	dataStore.taxPercentage = tax

	
	SetNuiFocus(true, true)
	SendNUIMessage({
		type = "open",
		data = {
			atm = isAtm,
			transferTax = dataStore.transferTax,
			taxPercentage = dataStore.taxPercentage,
			salaryNumber = dataStore.salaryNumber,
			salaryAfterTaxes = dataStore.salaryAfterTaxes,
			canTakeSalary = takeSalary
		}
	})
end

function refresh()
	local salary = getAccount('salary')
	local tax = 0
	local transferTax = 0
	if Config.Tax.enabled then 
		tax = Config.Tax.rate
		transferTax = Config.Tax.transfer
	end
	
	dataStore.transferTax = transferTax
	dataStore.taxPercentage = tax
	dataStore.salaryNumber = salary.money
	dataStore.salaryAfterTaxes = salary.money - (salary.money * (tax / 100))
	
	SetNuiFocus(true, true)
	SendNUIMessage({
		type = "refresh",
		data = {
			transferTax = dataStore.transferTax,
			taxPercentage = dataStore.taxPercentage,
			salaryNumber = dataStore.salaryNumber,
			salaryAfterTaxes = dataStore.salaryAfterTaxes
		}
	})
end

Citizen.CreateThread(function()
	for _,bank in ipairs(Config.Banks) do
		if bank.blip.enabled then
			local blip = AddBlipForCoord(bank.coords.x, bank.coords.y, bank.coords.z)
			SetBlipSprite(blip, bank.blip.id)
			SetBlipScale(blip, bank.blip.scale)
			SetBlipColour(blip, bank.blip.color)
			SetBlipAsShortRange(blip, true)
			BeginTextCommandSetBlipName("STRING")
			AddTextComponentString(tostring(bank.name))
			EndTextCommandSetBlipName(blip)
		end
		if bank.ped then
			bank.ped.entity = _CreatePed(GetHashKey(bank.ped.model), vector3(bank.ped.coords.x, bank.ped.coords.y, bank.ped.coords.z), bank.ped.coords.h)
		end
	end
	for _,atm in ipairs(Config.Atms) do
		if atm.blip.enabled then
			local blip = AddBlipForCoord(atm.coords.x, atm.coords.y, atm.coords.z)
			SetBlipSprite(blip, atm.blip.id)
			SetBlipScale(blip, atm.blip.scale)
			SetBlipColour(blip, atm.blip.color)
			SetBlipAsShortRange(blip, true)
			BeginTextCommandSetBlipName("STRING")
			AddTextComponentString(tostring(atm.name))
			EndTextCommandSetBlipName(blip)
		end
	end
end)


RegisterNUICallback('deposit', function(data)
	TriggerServerEvent('vb-banking:server:depositvb', tonumber(data.amount), inMenu)
	refresh()
end)

RegisterNUICallback('withdraw', function(data)
	TriggerServerEvent('vb-banking:server:withdrawvb', tonumber(data.amount), inMenu)
	refresh()
end)

RegisterNUICallback('transfer', function(data)
	TriggerServerEvent('vb-banking:server:transfervb', data.id, data.amount)
	refresh()
end)

RegisterNUICallback('takeSalary', function(_src)
	TriggerEvent('dx-paycheck:Menu', _src)
	Wait(500)
	refresh()
end)


RegisterNUICallback('NUIFocusOff', function()
	SetNuiFocus(false, false)
	ClearPedTasksImmediately(PlayerPedId())
	SendNUIMessage({type = 'close'})
end)